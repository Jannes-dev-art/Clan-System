import os
import asyncio
import random
import sqlite3
from datetime import datetime, timedelta, timezone

import discord
from discord import app_commands
from discord.ext import commands

TOKEN = os.getenv("DISCORD_TOKEN")
DB_PATH = os.getenv("DB_PATH", "data/bot.db")

if not TOKEN:
    raise RuntimeError("DISCORD_TOKEN is not set. Add it as a secret/environment variable on your host.")

os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)

intents = discord.Intents.default()
intents.members = True
intents.message_content = True
intents.voice_states = True

bot = commands.Bot(command_prefix="!", intents=intents)
tree = bot.tree


def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    con = db()
    con.executescript("""
    CREATE TABLE IF NOT EXISTS warnings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        moderator_id INTEGER NOT NULL,
        reason TEXT NOT NULL,
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS settings (
        guild_id INTEGER PRIMARY KEY,
        log_channel_id INTEGER,
        welcome_channel_id INTEGER,
        autorole_id INTEGER,
        verify_channel_id INTEGER,
        verify_role_id INTEGER
    );
    """)
    con.commit()
    con.close()


def get_settings(guild_id):
    con = db()
    row = con.execute("SELECT * FROM settings WHERE guild_id=?", (guild_id,)).fetchone()
    con.close()
    return row


def set_setting(guild_id, column, value):
    allowed = {"log_channel_id", "welcome_channel_id", "autorole_id", "verify_channel_id", "verify_role_id"}
    if column not in allowed:
        raise ValueError("invalid setting")
    con = db()
    con.execute("INSERT OR IGNORE INTO settings(guild_id) VALUES(?)", (guild_id,))
    con.execute(f"UPDATE settings SET {column}=? WHERE guild_id=?", (value, guild_id))
    con.commit()
    con.close()


async def send_log(guild, title, description):
    settings = get_settings(guild.id)
    if not settings or not settings["log_channel_id"]:
        return
    channel = guild.get_channel(settings["log_channel_id"])
    if channel:
        embed = discord.Embed(title=title, description=description, color=discord.Color.blurple(), timestamp=datetime.now(timezone.utc))
        try:
            await channel.send(embed=embed)
        except discord.HTTPException:
            pass


class ConfirmView(discord.ui.View):
    def __init__(self, callback):
        super().__init__(timeout=60)
        self.callback_fn = callback

    @discord.ui.button(label="Bestätigen", style=discord.ButtonStyle.danger)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.callback_fn(interaction)
        self.stop()

    @discord.ui.button(label="Abbrechen", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(content="Abgebrochen.", embed=None, view=None)
        self.stop()


class VerifyView(discord.ui.View):
    def __init__(self, role_id):
        super().__init__(timeout=None)
        self.role_id = role_id

    @discord.ui.button(label="Verifizieren", emoji="✅", style=discord.ButtonStyle.success, custom_id="verify_button")
    async def verify(self, interaction: discord.Interaction, button: discord.ui.Button):
        role = interaction.guild.get_role(self.role_id)
        if not role:
            return await interaction.response.send_message("Verifizierungsrolle nicht gefunden.", ephemeral=True)
        if role in interaction.user.roles:
            return await interaction.response.send_message("Du bist bereits verifiziert.", ephemeral=True)
        try:
            await interaction.user.add_roles(role, reason="Verification")
            await interaction.response.send_message("Du wurdest verifiziert! ✅", ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message("Ich kann die Rolle nicht vergeben. Prüfe meine Rolle und Berechtigungen.", ephemeral=True)


class TicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Ticket erstellen", emoji="🎫", style=discord.ButtonStyle.primary, custom_id="ticket_create")
    async def create_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        guild = interaction.guild
        category = discord.utils.get(guild.categories, name="Tickets")
        if not category:
            category = await guild.create_category("Tickets", reason="Ticket system setup")

        existing = discord.utils.get(category.text_channels, name=f"ticket-{interaction.user.id}")
        if existing:
            return await interaction.response.send_message(f"Du hast bereits ein Ticket: {existing.mention}", ephemeral=True)

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True),
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True, read_message_history=True)
        }
        channel = await category.create_text_channel(
            f"ticket-{interaction.user.id}",
            overwrites=overwrites,
            reason="Ticket created"
        )
        embed = discord.Embed(title="🎫 Ticket", description="Beschreibe dein Anliegen. Ein Teammitglied wird dir helfen.", color=discord.Color.blurple())
        await channel.send(content=interaction.user.mention, embed=embed, view=CloseTicketView())
        await interaction.response.send_message(f"Ticket erstellt: {channel.mention}", ephemeral=True)
        await send_log(guild, "Ticket erstellt", f"{interaction.user.mention} → {channel.mention}")


class CloseTicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Ticket schließen", emoji="🔒", style=discord.ButtonStyle.danger, custom_id="ticket_close")
    async def close(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("Ticket wird geschlossen…")
        await asyncio.sleep(2)
        try:
            await interaction.channel.delete(reason=f"Ticket closed by {interaction.user}")
        except discord.Forbidden:
            pass


class GiveawayView(discord.ui.View):
    def __init__(self, message_id):
        super().__init__(timeout=None)
        self.message_id = message_id

    @discord.ui.button(label="Teilnehmen", emoji="🎉", style=discord.ButtonStyle.success, custom_id="giveaway_join")
    async def join(self, interaction: discord.Interaction, button: discord.ui.Button):
        # In-memory participation is intentionally simple for this starter.
        participants = giveaway_participants.setdefault(self.message_id, set())
        if interaction.user.id in participants:
            participants.remove(interaction.user.id)
            return await interaction.response.send_message("Du bist nicht mehr dabei.", ephemeral=True)
        participants.add(interaction.user.id)
        await interaction.response.send_message("Du nimmst jetzt am Giveaway teil! 🎉", ephemeral=True)


giveaway_participants = {}
active_giveaways = {}


@bot.event
async def on_ready():
    init_db()
    bot.add_view(TicketView())
    bot.add_view(CloseTicketView())
    # Sync commands globally. Discord may take a little time to propagate global commands.
    try:
        await tree.sync()
    except Exception as e:
        print("Command sync error:", e)
    print(f"Online als {bot.user} ({bot.user.id})")


@bot.event
async def on_member_join(member):
    settings = get_settings(member.guild.id)
    if settings:
        if settings["autorole_id"]:
            role = member.guild.get_role(settings["autorole_id"])
            if role:
                try:
                    await member.add_roles(role, reason="Autorole")
                except discord.Forbidden:
                    pass
        if settings["welcome_channel_id"]:
            channel = member.guild.get_channel(settings["welcome_channel_id"])
            if channel:
                try:
                    await channel.send(f"Willkommen {member.mention}! 👋")
                except discord.HTTPException:
                    pass
    await send_log(member.guild, "Mitglied beigetreten", f"{member.mention} ist beigetreten.")


@bot.event
async def on_member_remove(member):
    await send_log(member.guild, "Mitglied verlassen", f"**{member}** hat den Server verlassen.")


@tree.command(name="ping", description="Zeigt die Bot-Latenz.")
async def ping(interaction: discord.Interaction):
    await interaction.response.send_message(f"🏓 Pong! `{round(bot.latency * 1000)} ms`")


@tree.command(name="setup", description="Richtet wichtige Bot-Kanäle/Rollen ein.")
@app_commands.checks.has_permissions(manage_guild=True)
async def setup(interaction: discord.Interaction):
    guild = interaction.guild
    category = discord.utils.get(guild.categories, name="MANAGEMENT")
    if not category:
        category = await guild.create_category("MANAGEMENT", reason="Management setup")

    log = discord.utils.get(category.text_channels, name="logs") or await category.create_text_channel("logs")
    tickets = discord.utils.get(category.text_channels, name="tickets") or await category.create_text_channel("tickets")
    welcome = discord.utils.get(category.text_channels, name="welcome") or await category.create_text_channel("welcome")

    set_setting(guild.id, "log_channel_id", log.id)
    set_setting(guild.id, "welcome_channel_id", welcome.id)

    await tickets.send(
        embed=discord.Embed(title="🎫 Support", description="Klicke auf den Button, um ein Ticket zu erstellen.", color=discord.Color.blurple()),
        view=TicketView()
    )
    await interaction.response.send_message(
        f"Setup abgeschlossen. Logs: {log.mention} · Tickets: {tickets.mention} · Welcome: {welcome.mention}",
        ephemeral=True
    )


@tree.command(name="warn", description="Verwarnt einen Benutzer.")
@app_commands.describe(member="Benutzer", reason="Grund")
@app_commands.checks.has_permissions(moderate_members=True)
async def warn(interaction: discord.Interaction, member: discord.Member, reason: str):
    con = db()
    con.execute(
        "INSERT INTO warnings(guild_id,user_id,moderator_id,reason,created_at) VALUES(?,?,?,?,?)",
        (interaction.guild.id, member.id, interaction.user.id, reason, datetime.now(timezone.utc).isoformat())
    )
    con.commit()
    con.close()
    await interaction.response.send_message(f"⚠️ {member.mention} wurde verwarnt: **{reason}**")
    await send_log(interaction.guild, "Warn", f"{member.mention} wurde von {interaction.user.mention} verwarnt.\nGrund: {reason}")


@tree.command(name="warnings", description="Zeigt Verwarnungen eines Benutzers.")
@app_commands.describe(member="Benutzer")
@app_commands.checks.has_permissions(moderate_members=True)
async def warnings(interaction: discord.Interaction, member: discord.Member):
    con = db()
    rows = con.execute(
        "SELECT reason, moderator_id, created_at FROM warnings WHERE guild_id=? AND user_id=? ORDER BY id DESC LIMIT 10",
        (interaction.guild.id, member.id)
    ).fetchall()
    con.close()
    if not rows:
        return await interaction.response.send_message(f"{member.mention} hat keine gespeicherten Verwarnungen.")
    lines = [f"• {r['reason']} — <@{r['moderator_id']}> ({r['created_at'][:10]})" for r in rows]
    embed = discord.Embed(title=f"Verwarnungen: {member}", description="\n".join(lines), color=discord.Color.orange())
    await interaction.response.send_message(embed=embed)


@tree.command(name="clear", description="Löscht Nachrichten.")
@app_commands.describe(amount="Anzahl")
@app_commands.checks.has_permissions(manage_messages=True)
async def clear(interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100]):
    await interaction.response.defer(ephemeral=True)
    deleted = await interaction.channel.purge(limit=amount)
    await interaction.followup.send(f"🧹 {len(deleted)} Nachrichten gelöscht.", ephemeral=True)


@tree.command(name="kick", description="Kickt einen Benutzer.")
@app_commands.describe(member="Benutzer", reason="Grund")
@app_commands.checks.has_permissions(kick_members=True)
async def kick(interaction: discord.Interaction, member: discord.Member, reason: str = "Kein Grund angegeben"):
    await member.kick(reason=reason)
    await interaction.response.send_message(f"👢 {member} wurde gekickt.\nGrund: {reason}")
    await send_log(interaction.guild, "Kick", f"{member} wurde von {interaction.user} gekickt.\nGrund: {reason}")


@tree.command(name="ban", description="Bannt einen Benutzer.")
@app_commands.describe(member="Benutzer", reason="Grund")
@app_commands.checks.has_permissions(ban_members=True)
async def ban(interaction: discord.Interaction, member: discord.Member, reason: str = "Kein Grund angegeben"):
    await member.ban(reason=reason)
    await interaction.response.send_message(f"🔨 {member} wurde gebannt.\nGrund: {reason}")
    await send_log(interaction.guild, "Ban", f"{member} wurde von {interaction.user} gebannt.\nGrund: {reason}")


@tree.command(name="timeout", description="Gibt einem Benutzer einen Timeout.")
@app_commands.describe(member="Benutzer", minutes="Minuten", reason="Grund")
@app_commands.checks.has_permissions(moderate_members=True)
async def timeout(interaction: discord.Interaction, member: discord.Member, minutes: app_commands.Range[int, 1, 40320], reason: str = "Kein Grund angegeben"):
    until = discord.utils.utcnow() + timedelta(minutes=minutes)
    await member.timeout(until, reason=reason)
    await interaction.response.send_message(f"⏳ {member.mention} hat für **{minutes} Minuten** Timeout.\nGrund: {reason}")
    await send_log(interaction.guild, "Timeout", f"{member} → {minutes} Minuten\nGrund: {reason}")


@tree.command(name="userinfo", description="Zeigt Informationen über einen Benutzer.")
async def userinfo(interaction: discord.Interaction, member: discord.Member | None = None):
    member = member or interaction.user
    embed = discord.Embed(title=f"👤 {member}", color=discord.Color.blurple())
    embed.set_thumbnail(url=member.display_avatar.url)
    embed.add_field(name="ID", value=str(member.id))
    embed.add_field(name="Erstellt", value=discord.utils.format_dt(member.created_at, "D"))
    embed.add_field(name="Beigetreten", value=discord.utils.format_dt(member.joined_at, "D") if member.joined_at else "Unbekannt")
    embed.add_field(name="Rollen", value=", ".join(r.mention for r in member.roles[1:]) or "Keine")
    await interaction.response.send_message(embed=embed)


@tree.command(name="serverinfo", description="Zeigt Serverinformationen.")
async def serverinfo(interaction: discord.Interaction):
    g = interaction.guild
    embed = discord.Embed(title=f"🛡️ {g.name}", color=discord.Color.blurple())
    if g.icon:
        embed.set_thumbnail(url=g.icon.url)
    embed.add_field(name="Mitglieder", value=str(g.member_count))
    embed.add_field(name="Kanäle", value=str(len(g.channels)))
    embed.add_field(name="Rollen", value=str(len(g.roles)))
    embed.add_field(name="Server-ID", value=str(g.id))
    await interaction.response.send_message(embed=embed)


@tree.command(name="announce", description="Sendet eine Ankündigung.")
@app_commands.describe(channel="Kanal", title="Titel", message="Text")
@app_commands.checks.has_permissions(manage_guild=True)
async def announce(interaction: discord.Interaction, channel: discord.TextChannel, title: str, message: str):
    embed = discord.Embed(title=f"📢 {title}", description=message, color=discord.Color.blurple(), timestamp=datetime.now(timezone.utc))
    embed.set_footer(text=f"Ankündigung von {interaction.user}")
    await channel.send(embed=embed)
    await interaction.response.send_message("Ankündigung gesendet.", ephemeral=True)


@tree.command(name="ticket", description="Sendet ein Ticket-Panel.")
@app_commands.checks.has_permissions(manage_guild=True)
async def ticket(interaction: discord.Interaction):
    embed = discord.Embed(title="🎫 Support", description="Klicke unten auf **Ticket erstellen**.", color=discord.Color.blurple())
    await interaction.channel.send(embed=embed, view=TicketView())
    await interaction.response.send_message("Ticket-Panel gesendet.", ephemeral=True)


@tree.command(name="verify", description="Sendet ein Verifizierungs-Panel.")
@app_commands.describe(role="Rolle, die vergeben wird")
@app_commands.checks.has_permissions(manage_guild=True)
async def verify(interaction: discord.Interaction, role: discord.Role):
    set_setting(interaction.guild.id, "verify_channel_id", interaction.channel.id)
    set_setting(interaction.guild.id, "verify_role_id", role.id)
    embed = discord.Embed(title="✅ Verifizierung", description="Klicke auf den Button, um dich zu verifizieren.", color=discord.Color.green())
    await interaction.channel.send(embed=embed, view=VerifyView(role.id))
    await interaction.response.send_message("Verifizierungs-Panel gesendet.", ephemeral=True)


@tree.command(name="autorole", description="Setzt die Autorolle.")
@app_commands.describe(role="Rolle")
@app_commands.checks.has_permissions(manage_guild=True)
async def autorole(interaction: discord.Interaction, role: discord.Role):
    set_setting(interaction.guild.id, "autorole_id", role.id)
    await interaction.response.send_message(f"Autorole gesetzt: {role.mention}", ephemeral=True)


@tree.command(name="giveaway", description="Startet ein Giveaway.")
@app_commands.describe(minutes="Dauer in Minuten", winners="Anzahl Gewinner", prize="Preis")
@app_commands.checks.has_permissions(manage_guild=True)
async def giveaway(interaction: discord.Interaction, minutes: app_commands.Range[int, 1, 10080], winners: app_commands.Range[int, 1, 20], prize: str):
    end = datetime.now(timezone.utc) + timedelta(minutes=minutes)
    embed = discord.Embed(title="🎉 GIVEAWAY", description=f"**Preis:** {prize}\n**Gewinner:** {winners}\n**Ende:** {discord.utils.format_dt(end, 'R')}\n\nKlicke auf **Teilnehmen**!", color=discord.Color.gold())
    await interaction.response.send_message(embed=embed)
    msg = await interaction.original_response()
    giveaway_participants[msg.id] = set()
    active_giveaways[msg.id] = {"channel_id": interaction.channel.id, "end": end, "winners": winners, "prize": prize}
    await msg.edit(view=GiveawayView(msg.id))
    asyncio.create_task(finish_giveaway(msg.id))


async def finish_giveaway(message_id):
    data = active_giveaways.get(message_id)
    if not data:
        return
    delay = max(0, (data["end"] - datetime.now(timezone.utc)).total_seconds())
    await asyncio.sleep(delay)
    participants = list(giveaway_participants.get(message_id, set()))
    active_giveaways.pop(message_id, None)
    if not participants:
        return
    selected = random.sample(participants, min(data["winners"], len(participants)))
    guild = bot.get_channel(data["channel_id"]).guild if bot.get_channel(data["channel_id"]) else None
    if guild:
        mentions = ", ".join(f"<@{uid}>" for uid in selected)
        await bot.get_channel(data["channel_id"]).send(f"🎉 Giveaway beendet! Preis: **{data['prize']}**\nGewinner: {mentions}")


@tree.error
async def on_app_command_error(interaction, error):
    if isinstance(error, app_commands.MissingPermissions):
        msg = "❌ Dir fehlen die nötigen Berechtigungen."
    elif isinstance(error, app_commands.CommandInvokeError):
        msg = f"❌ Fehler: `{error.original}`"
    else:
        msg = f"❌ Fehler: `{error}`"
    if interaction.response.is_done():
        await interaction.followup.send(msg, ephemeral=True)
    else:
        await interaction.response.send_message(msg, ephemeral=True)


if __name__ == "__main__":
    bot.run(TOKEN)
