# Helix-Style Discord Management Bot (Python)

Ein umfangreicher Discord-Management-Bot als Python-Projekt mit `discord.py` und SQLite.

## Enthalten

- Slash Commands
- `/ping`
- `/setup`
- `/warn` und `/warnings`
- `/clear`
- `/kick`
- `/ban`
- `/timeout`
- `/userinfo`
- `/serverinfo`
- `/announce`
- Ticket-System mit Buttons
- Verifizierung mit Button
- Autorole
- Join-/Leave-Logs
- Giveaways
- SQLite-Datenbank

## Start auf dem PC

Python 3.12 installieren, dann:

```bash
pip install -r requirements.txt
```

Token als Umgebungsvariable setzen.

Windows PowerShell:
```powershell
$env:DISCORD_TOKEN="DEIN_TOKEN"
python bot.py
```

Linux:
```bash
export DISCORD_TOKEN="DEIN_TOKEN"
python3 bot.py
```

## Bot-Token

Den Token niemals in `bot.py`, GitHub oder in Chat-Nachrichten eintragen.
Auf einem Hoster als Secret/Environment Variable mit dem Namen `DISCORD_TOKEN` setzen.

## Discord Developer Portal

Der Bot benötigt je nach verwendeten Funktionen passende Bot-Berechtigungen. Für Member-/Message-Funktionen können außerdem die entsprechenden Privileged Gateway Intents nötig sein.

Empfohlene Berechtigungen für einen Management-Bot:
- View Channels
- Send Messages
- Embed Links
- Read Message History
- Manage Messages
- Kick Members
- Ban Members
- Moderate Members
- Manage Roles
- Manage Channels

Gib dem Bot nicht mehr Rechte als nötig und setze seine Bot-Rolle oberhalb der Rollen, die er verwalten soll.

## Hinweis

Das Projekt ist ein funktionsreicher Startpunkt im Stil eines Management-Bots, aber kein 1:1-Klon eines kommerziellen Bots. Erweiterungen wie Dashboard, vollständige AutoMod-Regeln, Transcript-Export, persistente Giveaway-Teilnehmer, komplexe Ticket-Teams, Economy/Coins und weitere Module können darauf aufgebaut werden.
