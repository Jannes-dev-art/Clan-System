# HelixStyleBot

Java 21 + Maven + JDA Discord management bot starter.

Included:
- /ping
- /setup
- /warn
- /warnings
- /clear
- /kick
- /ban
- /ticket
- /verify
- /giveaway
- /userinfo
- SQLite persistence for warnings and guild settings
- Ticket and verification buttons
- Giveaway button

## Start
1. Open the folder in IntelliJ IDEA.
2. Let Maven import dependencies.
3. Create a Discord application/bot in the Discord Developer Portal.
4. Create an IntelliJ Run Configuration for `de.helixstyle.Main`.
5. Add environment variable `DISCORD_TOKEN=YOUR_TOKEN`.
6. Run Main.
7. Invite the bot with `bot` and `applications.commands` scopes.
8. Run `/setup`.

Never put the bot token into GitHub or send it to anyone.
