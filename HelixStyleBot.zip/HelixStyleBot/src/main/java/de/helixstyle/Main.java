package de.helixstyle;

import de.helixstyle.commands.*;
import de.helixstyle.db.Database;
import de.helixstyle.events.ButtonListener;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.OnlineStatus;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.interactions.commands.build.Commands;

public class Main {
    public static void main(String[] args) throws Exception {
        String token = System.getenv("DISCORD_TOKEN");
        if (token == null || token.isBlank()) {
            System.err.println("DISCORD_TOKEN fehlt. Trage ihn als Environment Variable ein.");
            return;
        }

        Database.init();

        JDA jda = JDABuilder.createDefault(token)
                .setStatus(OnlineStatus.ONLINE)
                .setActivity(Activity.playing("Management"))
                .addEventListeners(
                        new ButtonListener(),
                        new PingCommand(),
                        new SetupCommand(),
                        new ModerationCommands(),
                        new TicketCommand(),
                        new VerifyCommand(),
                        new GiveawayCommand(),
                        new UserInfoCommand()
                )
                .build();

        jda.awaitReady();

        jda.updateCommands()
                .addCommands(
                        Commands.slash("ping", "Zeigt die Bot-Latenz"),
                        Commands.slash("setup", "Erstellt die Management-Struktur"),
                        Commands.slash("warn", "Warnt einen Benutzer").addOption(net.dv8tion.jda.api.interactions.commands.OptionType.USER, "user", "Benutzer", true).addOption(net.dv8tion.jda.api.interactions.commands.OptionType.STRING, "reason", "Grund", true),
                        Commands.slash("warnings", "Zeigt Warnungen eines Benutzers").addOption(net.dv8tion.jda.api.interactions.commands.OptionType.USER, "user", "Benutzer", true),
                        Commands.slash("clear", "Löscht Nachrichten").addOption(net.dv8tion.jda.api.interactions.commands.OptionType.INTEGER, "amount", "Anzahl", true),
                        Commands.slash("kick", "Kickt einen Benutzer").addOption(net.dv8tion.jda.api.interactions.commands.OptionType.USER, "user", "Benutzer", true),
                        Commands.slash("ban", "Bannt einen Benutzer").addOption(net.dv8tion.jda.api.interactions.commands.OptionType.USER, "user", "Benutzer", true),
                        Commands.slash("ticket", "Sendet das Ticket-Panel"),
                        Commands.slash("verify", "Sendet das Verifizierungs-Panel"),
                        Commands.slash("giveaway", "Startet ein Giveaway").addOption(net.dv8tion.jda.api.interactions.commands.OptionType.STRING, "prize", "Preis", true).addOption(net.dv8tion.jda.api.interactions.commands.OptionType.INTEGER, "seconds", "Dauer in Sekunden", true),
                        Commands.slash("userinfo", "Zeigt Benutzerinformationen").addOption(net.dv8tion.jda.api.interactions.commands.OptionType.USER, "user", "Benutzer", false)
                ).queue();

        System.out.println("Bot ist online als " + jda.getSelfUser().getAsTag());
    }
}
