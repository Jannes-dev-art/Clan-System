package de.helixstyle.db;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public final class Database {
    private static final String URL = "jdbc:sqlite:bot.db";

    private Database() {}

    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(URL);
    }

    public static void init() {
        try (Connection c = connect(); Statement s = c.createStatement()) {
            s.executeUpdate("""
                CREATE TABLE IF NOT EXISTS warnings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guild_id TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    moderator_id TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """);
            s.executeUpdate("""
                CREATE TABLE IF NOT EXISTS guild_settings (
                    guild_id TEXT PRIMARY KEY,
                    verify_role_id TEXT,
                    ticket_category_id TEXT,
                    log_channel_id TEXT
                )
            """);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void addWarning(String guild, String user, String moderator, String reason) throws SQLException {
        try (Connection c = connect();
             PreparedStatement p = c.prepareStatement(
                     "INSERT INTO warnings(guild_id,user_id,moderator_id,reason) VALUES(?,?,?,?)")) {
            p.setString(1, guild);
            p.setString(2, user);
            p.setString(3, moderator);
            p.setString(4, reason);
            p.executeUpdate();
        }
    }

    public static List<String> getWarnings(String guild, String user) throws SQLException {
        List<String> result = new ArrayList<>();
        try (Connection c = connect();
             PreparedStatement p = c.prepareStatement(
                     "SELECT id, reason, created_at FROM warnings WHERE guild_id=? AND user_id=? ORDER BY id DESC")) {
            p.setString(1, guild);
            p.setString(2, user);
            try (ResultSet r = p.executeQuery()) {
                while (r.next()) {
                    result.add("#" + r.getInt("id") + " — " + r.getString("reason") +
                            " (" + r.getString("created_at") + ")");
                }
            }
        }
        return result;
    }

    public static void setSetting(String guild, String column, String value) throws SQLException {
        if (!column.matches("verify_role_id|ticket_category_id|log_channel_id")) return;
        try (Connection c = connect()) {
            try (PreparedStatement p = c.prepareStatement(
                    "INSERT INTO guild_settings(guild_id," + column + ") VALUES(?,?) " +
                    "ON CONFLICT(guild_id) DO UPDATE SET " + column + "=excluded." + column)) {
                p.setString(1, guild);
                p.setString(2, value);
                p.executeUpdate();
            }
        }
    }

    public static String getSetting(String guild, String column) throws SQLException {
        if (!column.matches("verify_role_id|ticket_category_id|log_channel_id")) return null;
        try (Connection c = connect();
             PreparedStatement p = c.prepareStatement("SELECT " + column + " FROM guild_settings WHERE guild_id=?")) {
            p.setString(1, guild);
            try (ResultSet r = p.executeQuery()) {
                return r.next() ? r.getString(column) : null;
            }
        }
    }
}
