package de.helixstyle.events;

import de.helixstyle.db.Database;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.events.interaction.component.ButtonInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import java.util.concurrent.ConcurrentHashMap;

public class ButtonListener extends ListenerAdapter {
    private static final ConcurrentHashMap<Long, Boolean> ticketUsers = new ConcurrentHashMap<>();

    public void onButtonInteraction(ButtonInteractionEvent e) {
        String id = e.getComponentId();

        if (id.equals("verify:me")) {
            try {
                String roleId = Database.getSetting(e.getGuild().getId(), "verify_role_id");
                if (roleId == null) { e.reply("❌ Erst `/setup` ausführen.").setEphemeral(true).queue(); return; }
                e.getGuild().addRoleToMember(e.getUser(), e.getGuild().getRoleById(roleId)).queue();
                e.reply("✅ Du bist verifiziert!").setEphemeral(true).queue();
            } catch (Exception ex) { e.reply("❌ Fehler bei der Verifizierung.").setEphemeral(true).queue(); }
            return;
        }

        if (id.equals("ticket:create")) {
            if (ticketUsers.putIfAbsent(e.getUser().getIdLong(), true) != null) {
                e.reply("❌ Du hast bereits ein offenes Ticket.").setEphemeral(true).queue(); return;
            }
            e.getGuild().createTextChannel("ticket-" + e.getUser().getName())
                    .queue(ch -> {
                        ch.getManager().putPermissionOverride(e.getMember(), 1024L, 0L).queue();
                        ch.sendMessage("🎫 " + e.getUser().getAsMention() + " Dein Ticket wurde erstellt.").addActionRow(
                                net.dv8tion.jda.api.interactions.components.buttons.Button.danger("ticket:close", "🔒 Schließen")
                        ).queue();
                        e.reply("✅ Ticket erstellt: " + ch.getAsMention()).setEphemeral(true).queue();
                    });
            return;
        }

        if (id.equals("ticket:close")) {
            ticketUsers.remove(e.getUser().getIdLong());
            if (e.getMember().hasPermission(Permission.MANAGE_CHANNEL)) {
                e.getChannel().delete().queue();
            } else {
                e.reply("❌ Du brauchst Kanalverwaltungsrechte.").setEphemeral(true).queue();
            }
        }

        if (id.equals("giveaway:join")) {
            // Giveaway entries are kept by the giveaway command in its internal map.
            e.reply("🎉 Teilnahme registriert!").setEphemeral(true).queue();
        }
    }
}
