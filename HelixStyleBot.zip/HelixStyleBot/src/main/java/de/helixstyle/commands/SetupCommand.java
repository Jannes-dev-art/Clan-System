package de.helixstyle.commands;

import de.helixstyle.db.Database;
import net.dv8tion.jda.api.entities.*;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.Permission;

public class SetupCommand extends ListenerAdapter {
    public void onSlashCommandInteraction(SlashCommandInteractionEvent e) {
        if (!e.getName().equals("setup")) return;
        if (!e.getMember().hasPermission(Permission.ADMINISTRATOR)) {
            e.reply("❌ Du brauchst Administrator-Rechte.").setEphemeral(true).queue(); return;
        }
        Guild g = e.getGuild();
        e.deferReply(true).queue();
        g.createCategory("MANAGEMENT").queue(cat -> {
            cat.createTextChannel("tickets").queue(ch -> {});
            cat.createTextChannel("bewerbungen").queue(ch -> {});
            cat.createTextChannel("verification").queue(ch -> {});
            cat.createTextChannel("logs").queue(ch -> {
                try { Database.setSetting(g.getId(), "log_channel_id", ch.getId()); } catch (Exception ex) { ex.printStackTrace(); }
            });
        });
        g.createRole().setName("Verified").queue(role -> {
            try { Database.setSetting(g.getId(), "verify_role_id", role.getId()); } catch (Exception ex) { ex.printStackTrace(); }
        });
        e.getHook().sendMessage("✅ Grundstruktur und Verified-Rolle werden erstellt.").queue();
    }
}
