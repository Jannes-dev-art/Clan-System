package de.helixstyle.commands;

import de.helixstyle.db.Database;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.User;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import java.util.List;

public class ModerationCommands extends ListenerAdapter {
    public void onSlashCommandInteraction(SlashCommandInteractionEvent e) {
        try {
            switch (e.getName()) {
                case "warn" -> warn(e);
                case "warnings" -> warnings(e);
                case "clear" -> clear(e);
                case "kick" -> kick(e);
                case "ban" -> ban(e);
            }
        } catch (Exception ex) {
            e.reply("❌ Fehler: " + ex.getMessage()).setEphemeral(true).queue();
        }
    }

    private boolean admin(SlashCommandInteractionEvent e) {
        if (!e.getMember().hasPermission(Permission.MODERATE_MEMBERS)) {
            e.reply("❌ Keine Moderationsrechte.").setEphemeral(true).queue(); return false;
        }
        return true;
    }

    private void warn(SlashCommandInteractionEvent e) throws Exception {
        if (!admin(e)) return;
        User u = e.getOption("user").getAsUser();
        String reason = e.getOption("reason").getAsString();
        Database.addWarning(e.getGuild().getId(), u.getId(), e.getUser().getId(), reason);
        e.reply("⚠️ " + u.getAsMention() + " wurde verwarnt: **" + reason + "**").queue();
    }

    private void warnings(SlashCommandInteractionEvent e) throws Exception {
        if (!admin(e)) return;
        User u = e.getOption("user").getAsUser();
        List<String> ws = Database.getWarnings(e.getGuild().getId(), u.getId());
        e.reply(ws.isEmpty() ? "Keine Warnungen." : String.join("\n", ws)).setEphemeral(true).queue();
    }

    private void clear(SlashCommandInteractionEvent e) {
        if (!admin(e)) return;
        int amount = e.getOption("amount").getAsInt();
        e.getChannel().getHistory().retrievePast(Math.min(amount, 100)).queue(msgs ->
            e.getChannel().purgeMessages(msgs).queue(v ->
                e.reply("🧹 " + msgs.size() + " Nachrichten gelöscht.").setEphemeral(true).queue()));
    }

    private void kick(SlashCommandInteractionEvent e) {
        if (!admin(e)) return;
        var member = e.getOption("user").getAsMember();
        if (member == null) { e.reply("❌ Benutzer ist nicht auf dem Server.").setEphemeral(true).queue(); return; }
        e.getGuild().kick(member).queue(v -> e.reply("👢 " + member.getUser().getAsMention() + " wurde gekickt.").queue(),
                err -> e.reply("❌ Konnte Benutzer nicht kicken.").setEphemeral(true).queue());
    }

    private void ban(SlashCommandInteractionEvent e) {
        if (!admin(e)) return;
        User u = e.getOption("user").getAsUser();
        e.getGuild().ban(u, 0, "Ban durch " + e.getUser().getAsTag()).queue(
                v -> e.reply("🔨 " + u.getAsMention() + " wurde gebannt.").queue(),
                err -> e.reply("❌ Konnte Benutzer nicht bannen.").setEphemeral(true).queue());
    }
}
