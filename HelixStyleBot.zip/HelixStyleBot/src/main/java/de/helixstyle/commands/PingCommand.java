package de.helixstyle.commands;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
public class PingCommand extends ListenerAdapter {
    public void onSlashCommandInteraction(SlashCommandInteractionEvent e) {
        if (e.getName().equals("ping"))
            e.reply("🏓 Pong! `" + e.getJDA().getGatewayPing() + "ms`").queue();
    }
}
