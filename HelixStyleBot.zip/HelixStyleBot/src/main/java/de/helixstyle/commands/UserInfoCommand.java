package de.helixstyle.commands;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class UserInfoCommand extends ListenerAdapter {
    public void onSlashCommandInteraction(SlashCommandInteractionEvent e) {
        if (!e.getName().equals("userinfo")) return;
        var u = e.getOption("user") == null ? e.getUser() : e.getOption("user").getAsUser();
        e.replyEmbeds(new EmbedBuilder().setTitle("👤 Userinfo")
                .addField("Name", u.getAsTag(), true)
                .addField("ID", u.getId(), true)
                .addField("Account erstellt", u.getTimeCreated().toString(), false)
                .setThumbnail(u.getEffectiveAvatarUrl()).build()).queue();
    }
}
