package de.helixstyle.commands;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.components.buttons.Button;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

public class GiveawayCommand extends ListenerAdapter {
    private static final ConcurrentHashMap<Long, java.util.Set<Long>> entries = new ConcurrentHashMap<>();

    public void onSlashCommandInteraction(SlashCommandInteractionEvent e) {
        if (!e.getName().equals("giveaway")) return;
        String prize = e.getOption("prize").getAsString();
        int seconds = e.getOption("seconds").getAsInt();
        var msg = e.replyEmbeds(new EmbedBuilder().setTitle("🎉 Giveaway")
                .setDescription("Preis: **" + prize + "**\nEnde in **" + seconds + " Sekunden**")
                .build()).addActionRow(Button.success("giveaway:join", "🎉 Teilnehmen")).submit();
        msg.queue(hook -> {
            entries.put(hook.getIdLong(), ConcurrentHashMap.newKeySet());
            new Thread(() -> {
                try { Thread.sleep(seconds * 1000L); } catch (InterruptedException ignored) {}
                var set = entries.remove(hook.getIdLong());
                if (set == null || set.isEmpty()) hook.editOriginalEmbeds(
                        new EmbedBuilder().setTitle("🎉 Giveaway beendet")
                                .setDescription("Keine Teilnehmer.").build()).queue();
                else {
                    long winner = set.stream().skip(ThreadLocalRandom.current().nextInt(set.size())).findFirst().orElse(0L);
                    hook.editOriginalEmbeds(new EmbedBuilder().setTitle("🎉 Giveaway beendet")
                            .setDescription("Gewinner: <@" + winner + ">").build()).queue();
                }
            }).start();
        });
    }
}
