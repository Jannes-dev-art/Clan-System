# ClanControl Discord Bot

Ein **reiner Discord-Bot**. Es gibt kein Website-Panel und keinen Browser-Zwang. Einrichtung und Bedienung laufen über Discord:

- `/admin` öffnet das zentrale Admin-Panel als ephemere Discord-Nachricht.
- Buttons öffnen Module, Sicherheit und Minecraft-Verbindung.
- Ein Select-Menü schaltet die Module pro Discord-Server.
- Ein Modal nimmt Minecraft-Serveradresse, Port und Bot-Account auf.
- Konfigurationen werden serverisoliert in `data/guilds.json` gespeichert.

## Einrichtung

1. Im [Discord Developer Portal](https://discord.com/developers/applications) eine Application und einen Bot erstellen.
2. `DISCORD_TOKEN` und `DISCORD_CLIENT_ID` in `.env` setzen.
3. Den Bot mit den Scopes `bot` und `applications.commands` einladen. Für das MVP reichen `View Channels`, `Send Messages`, `Embed Links` und `Use Application Commands`.
4. `pnpm install` und `pnpm build` ausführen.
5. Mit `pnpm start` starten. Der Prozess muss dauerhaft laufen, weil Discord über eine Gateway-WebSocket-Verbindung arbeitet.

Beispiel `.env`:

```env
DISCORD_TOKEN=dein_bot_token
DISCORD_CLIENT_ID=deine_application_id
DATA_FILE=./data/guilds.json
```

## Minecraft

Der Discord-Flow speichert zunächst nur Serverziel und Accountnamen und markiert die Verbindung als `pending`. Für eine echte Java-Account-Verbindung wird im nächsten Schritt ein sicherer Microsoft-OAuth-/Device-Code-Flow und ein Minecraft-Adapter ergänzt. Es werden keine Minecraft-Passwörter im Bot gespeichert.

## Produktivbetrieb

Der Bot braucht einen dauerhaft laufenden Node-Prozess. Für Entwicklung reicht der lokale Rechner. Für 24/7-Betrieb sollte er auf einem persistenten Node-Host mit automatischem Neustart laufen. Der Bot ist unabhängig von der zuvor erstellten Website.
