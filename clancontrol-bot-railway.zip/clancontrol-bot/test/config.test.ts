import { describe, expect, it } from "vitest";
import { defaultGuildConfig, MODULES } from "../src/config.js";

describe("ClanControl guild configuration", () => {
  it("creates a complete server-isolated default", () => {
    const config = defaultGuildConfig("guild-1", "Test Clan");
    expect(config.guildId).toBe("guild-1");
    expect(config.guildName).toBe("Test Clan");
    expect(Object.keys(config.modules)).toHaveLength(MODULES.length);
    expect(config.modules.tickets).toBe(true);
    expect(config.modules.antiRaid).toBe(false);
    expect(config.minecraft.status).toBe("not_configured");
  });
});
