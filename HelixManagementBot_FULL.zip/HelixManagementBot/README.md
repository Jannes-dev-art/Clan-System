# HelixManagementBot

Eigener Discord-Management-Bot für IntelliJ IDEA.

Technik:
- Java 21
- Maven
- JDA 6.3.0
- SQLite

Enthalten:
- Moderation: ban, kick, timeout, warn, warnings, clear
- Ticket-System mit Button und Close
- Verification-System
- Giveaway-System mit Teilnahme und automatischer Auswahl
- TempVoice
- Autorole
- Logging für Join/Leave
- /setup
- /serverinfo
- /userinfo
- /announce
- persistente SQLite-Daten

START:
1. ZIP entpacken.
2. Ordner in IntelliJ öffnen.
3. Maven laden lassen.
4. Discord Developer Portal öffnen und Bot erstellen.
5. IntelliJ Run Configuration für de.helixmanagement.Main.
6. Environment variable setzen:
   DISCORD_TOKEN=DEIN_TOKEN
7. Bot mit Scopes bot + applications.commands einladen.
8. /setup ausführen.

Für Moderation benötigt der Bot die entsprechenden Discord-Rechte.
Den Token niemals veröffentlichen.
