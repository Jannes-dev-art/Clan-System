package de.helixmanagement.db;

import java.sql.*;
import java.util.*;

public final class Database {
    private static final String URL = "jdbc:sqlite:bot.db";
    private Database() {}

    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(URL);
    }

    public static void init() {
        try (Connection c = connect(); Statement s = c.createStatement()) {
            s.executeUpdate("""
                CREATE TABLE IF NOT EXISTS settings(
                    guild_id TEXT PRIMARY KEY,
                    verify_role TEXT,
                    ticket_category TEXT,
                    ticket_log TEXT,
                    log_channel TEXT,
                    autorole TEXT,
                    tempvoice_channel TEXT
                )
            """);
            s.executeUpdate("""
                CREATE TABLE IF NOT EXISTS warnings(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    guild_id TEXT,
                    user_id TEXT,
                    moderator_id TEXT,
                    reason TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """);
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public static void set(String guild, String column, String value) throws SQLException {
        if (!column.matches("verify_role|ticket_category|ticket_log|log_channel|autorole|tempvoice_channel")) return;
        try (Connection c=connect();
             PreparedStatement p=c.prepareStatement(
                 "INSERT INTO settings(guild_id,"+column+") VALUES(?,?) " +
                 "ON CONFLICT(guild_id) DO UPDATE SET "+column+"=excluded."+column)) {
            p.setString(1,guild); p.setString(2,value); p.executeUpdate();
        }
    }

    public static String get(String guild, String column) throws SQLException {
        if (!column.matches("verify_role|ticket_category|ticket_log|log_channel|autorole|tempvoice_channel")) return null;
        try (Connection c=connect();
             PreparedStatement p=c.prepareStatement("SELECT "+column+" FROM settings WHERE guild_id=?")) {
            p.setString(1,guild);
            try (ResultSet r=p.executeQuery()) { return r.next()?r.getString(1):null; }
        }
    }

    public static void warn(String guild,String user,String mod,String reason) throws SQLException {
        try(Connection c=connect(); PreparedStatement p=c.prepareStatement(
                "INSERT INTO warnings(guild_id,user_id,moderator_id,reason) VALUES(?,?,?,?)")) {
            p.setString(1,guild);p.setString(2,user);p.setString(3,mod);p.setString(4,reason);p.executeUpdate();
        }
    }

    public static List<String> warnings(String guild,String user) throws SQLException {
        List<String> out=new ArrayList<>();
        try(Connection c=connect();PreparedStatement p=c.prepareStatement(
                "SELECT id,reason,created_at FROM warnings WHERE guild_id=? AND user_id=? ORDER BY id DESC")) {
            p.setString(1,guild);p.setString(2,user);
            try(ResultSet r=p.executeQuery()) {
                while(r.next()) out.add("#"+r.getInt(1)+" — "+r.getString(2)+" — "+r.getString(3));
            }
        }
        return out;
    }
}
