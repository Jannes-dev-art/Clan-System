package de.helixmanagement.events;

import de.helixmanagement.commands.GiveawayCommand;
import de.helixmanagement.db.Database;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.events.interaction.component.ButtonInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.components.buttons.Button;

import java.util.concurrent.ConcurrentHashMap;

public class ButtonListener extends ListenerAdapter {
    private static final ConcurrentHashMap<Long,Long> ticketOwners=new ConcurrentHashMap<>();

    public void onButtonInteraction(ButtonInteractionEvent e) {
        try {
            String id=e.getComponentId();

            if(id.equals("verify:me")) {
                String rid=Database.get(e.getGuild().getId(),"verify_role");
                if(rid==null){e.reply("❌ Bitte zuerst `/setup` ausführen.").setEphemeral(true).queue();return;}
                var role=e.getGuild().getRoleById(rid);
                if(role==null){e.reply("❌ Verified-Rolle nicht gefunden.").setEphemeral(true).queue();return;}
                e.getGuild().addRoleToMember(e.getMember(),role).queue(
                        v->e.reply("✅ Du bist verifiziert!").setEphemeral(true).queue(),
                        x->e.reply("❌ Rolle konnte nicht vergeben werden.").setEphemeral(true).queue());
                return;
            }

            if(id.equals("ticket:create")) {
                e.deferReply(true).queue();
                e.getGuild().createTextChannel("ticket-"+e.getUser().getName()).queue(ch->{
                    ticketOwners.put(ch.getIdLong(),e.getUser().getIdLong());
                    ch.sendMessage(e.getUser().getAsMention()+"\n🎫 **Ticket geöffnet.**\nBeschreibe dein Anliegen.")
                            .addActionRow(Button.danger("ticket:close","🔒 Ticket schließen")).queue();
                    e.getHook().sendMessage("✅ Ticket: "+ch.getAsMention()).queue();
                });
                return;
            }

            if(id.equals("ticket:close")) {
                if(!e.getMember().hasPermission(Permission.MANAGE_CHANNEL)) {
                    e.reply("❌ Teamrechte erforderlich.").setEphemeral(true).queue();return;
                }
                ticketOwners.remove(e.getChannel().getIdLong());
                e.getChannel().delete().queue();
                return;
            }

            if(id.equals("giveaway:join")) {
                var set=GiveawayCommand.entries.get(e.getMessageIdLong());
                if(set==null){e.reply("❌ Giveaway ist beendet.").setEphemeral(true).queue();return;}
                if(!set.add(e.getUser().getIdLong())){
                    e.reply("ℹ️ Du bist bereits dabei.").setEphemeral(true).queue();return;
                }
                e.reply("🎉 Du nimmst teil!").setEphemeral(true).queue();
            }
        } catch(Exception ex) { e.reply("❌ Fehler: "+ex.getMessage()).setEphemeral(true).queue(); }
    }
}
