package de.helixmanagement.events;

import de.helixmanagement.db.Database;
import net.dv8tion.jda.api.events.guild.voice.GuildVoiceUpdateEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class VoiceListener extends ListenerAdapter {
    private static final Set<Long> temporaryChannels=ConcurrentHashMap.newKeySet();

    public void onGuildVoiceUpdate(GuildVoiceUpdateEvent e) {
        try {
            String trigger=Database.get(e.getGuild().getId(),"tempvoice_channel");
            if(e.getChannelJoined()!=null && trigger!=null && e.getChannelJoined().getId().equals(trigger)) {
                e.getGuild().createVoiceChannel("🔊 "+e.getMember().getEffectiveName()).queue(ch->{
                    temporaryChannels.add(ch.getIdLong());
                    e.getGuild().moveVoiceMember(e.getMember(),ch).queue();
                });
            }
            if(e.getChannelLeft()!=null && temporaryChannels.contains(e.getChannelLeft().getIdLong())
                    && e.getChannelLeft().getMembers().isEmpty()) {
                temporaryChannels.remove(e.getChannelLeft().getIdLong());
                e.getChannelLeft().delete().queue();
            }
        }catch(Exception ignored){}
    }
}
