package de.helixmanagement.events;

import de.helixmanagement.db.Database;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.events.guild.member.GuildMemberJoinEvent;
import net.dv8tion.jda.api.events.guild.member.GuildMemberRemoveEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class GuildListener extends ListenerAdapter {
    public void onGuildMemberJoin(GuildMemberJoinEvent e) {
        try {
            String roleId=Database.get(e.getGuild().getId(),"autorole");
            if(roleId!=null && e.getGuild().getRoleById(roleId)!=null)
                e.getGuild().addRoleToMember(e.getMember(),e.getGuild().getRoleById(roleId)).queue();
            String log=Database.get(e.getGuild().getId(),"log_channel");
            if(log!=null) e.getGuild().getTextChannelById(log).sendMessageEmbeds(
                new EmbedBuilder().setTitle("📥 Member Join").setDescription(e.getUser().getAsMention()+" ist beigetreten.").build()).queue();
        }catch(Exception ignored){}
    }
    public void onGuildMemberRemove(GuildMemberRemoveEvent e) {
        try {
            String log=Database.get(e.getGuild().getId(),"log_channel");
            if(log!=null) e.getGuild().getTextChannelById(log).sendMessageEmbeds(
                new EmbedBuilder().setTitle("📤 Member Leave").setDescription(e.getUser().getAsTag()+" hat den Server verlassen.").build()).queue();
        }catch(Exception ignored){}
    }
}
