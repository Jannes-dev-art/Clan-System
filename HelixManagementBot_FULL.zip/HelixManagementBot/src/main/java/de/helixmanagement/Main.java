package de.helixmanagement;

import de.helixmanagement.db.Database;
import de.helixmanagement.events.ButtonListener;
import de.helixmanagement.events.GuildListener;
import de.helixmanagement.events.VoiceListener;
import de.helixmanagement.commands.*;
import net.dv8tion.jda.api.*;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.Commands;

public class Main {
    public static void main(String[] args) throws Exception {
        String token = System.getenv("DISCORD_TOKEN");
        if (token == null || token.isBlank()) {
            System.err.println("DISCORD_TOKEN fehlt.");
            return;
        }

        Database.init();

        JDA jda = JDABuilder.createDefault(token)
                .setActivity(Activity.playing("Management"))
                .addEventListeners(
                        new ButtonListener(),
                        new GuildListener(),
                        new VoiceListener(),
                        new BasicCommands(),
                        new ModerationCommands(),
                        new SetupCommand(),
                        new TicketCommand(),
                        new VerifyCommand(),
                        new GiveawayCommand(),
                        new AnnouncementCommand()
                )
                .build();

        jda.awaitReady();

        jda.updateCommands().addCommands(
                Commands.slash("ping", "Bot-Latenz"),
                Commands.slash("setup", "Erstellt die Grundstruktur"),
                Commands.slash("warn", "Warnt einen Benutzer")
                        .addOption(OptionType.USER, "user", "Benutzer", true)
                        .addOption(OptionType.STRING, "reason", "Grund", true),
                Commands.slash("warnings", "Zeigt Warnungen")
                        .addOption(OptionType.USER, "user", "Benutzer", true),
                Commands.slash("clear", "Löscht Nachrichten")
                        .addOption(OptionType.INTEGER, "amount", "Anzahl", true),
                Commands.slash("kick", "Kickt einen Benutzer")
                        .addOption(OptionType.USER, "user", "Benutzer", true),
                Commands.slash("ban", "Bannt einen Benutzer")
                        .addOption(OptionType.USER, "user", "Benutzer", true),
                Commands.slash("timeout", "Gibt einem Benutzer Timeout")
                        .addOption(OptionType.USER, "user", "Benutzer", true)
                        .addOption(OptionType.INTEGER, "minutes", "Minuten", true),
                Commands.slash("ticket", "Sendet das Ticket-Panel"),
                Commands.slash("verify", "Sendet das Verify-Panel"),
                Commands.slash("giveaway", "Startet ein Giveaway")
                        .addOption(OptionType.STRING, "prize", "Preis", true)
                        .addOption(OptionType.INTEGER, "seconds", "Dauer", true),
                Commands.slash("userinfo", "Benutzerinformationen")
                        .addOption(OptionType.USER, "user", "Benutzer", false),
                Commands.slash("serverinfo", "Serverinformationen"),
                Commands.slash("announce", "Sendet eine Ankündigung")
                        .addOption(OptionType.STRING, "text", "Text", true)
        ).queue();

        System.out.println("================================");
        System.out.println("BOT ONLINE: " + jda.getSelfUser().getAsTag());
        System.out.println("================================");
    }
}
