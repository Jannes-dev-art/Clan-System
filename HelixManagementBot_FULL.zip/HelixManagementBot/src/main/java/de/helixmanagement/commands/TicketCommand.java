package de.helixmanagement.commands;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.components.buttons.Button;

public class TicketCommand extends ListenerAdapter {
    public void onSlashCommandInteraction(SlashCommandInteractionEvent e) {
        if(!e.getName().equals("ticket"))return;
        e.replyEmbeds(new EmbedBuilder().setTitle("🎫 Support")
                .setDescription("Klicke auf **Ticket öffnen**.").build())
                .addActionRow(Button.primary("ticket:create","🎫 Ticket öffnen")).queue();
    }
}
