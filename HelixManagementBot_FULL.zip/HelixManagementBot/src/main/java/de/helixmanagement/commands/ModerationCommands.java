package de.helixmanagement.commands;

import de.helixmanagement.db.Database;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.User;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import java.time.Duration;
import java.util.List;

public class ModerationCommands extends ListenerAdapter {
    private boolean mod(SlashCommandInteractionEvent e) {
        if(!e.getMember().hasPermission(Permission.MODERATE_MEMBERS)) {
            e.reply("❌ Keine Moderationsrechte.").setEphemeral(true).queue(); return false;
        }
        return true;
    }
    public void onSlashCommandInteraction(SlashCommandInteractionEvent e) {
        try {
            switch(e.getName()) {
                case "warn" -> {
                    if(!mod(e)) return;
                    User u=e.getOption("user").getAsUser();
                    String reason=e.getOption("reason").getAsString();
                    Database.warn(e.getGuild().getId(),u.getId(),e.getUser().getId(),reason);
                    e.reply("⚠️ "+u.getAsMention()+" wurde verwarnt: **"+reason+"**").queue();
                }
                case "warnings" -> {
                    if(!mod(e)) return;
                    User u=e.getOption("user").getAsUser();
                    List<String> w=Database.warnings(e.getGuild().getId(),u.getId());
                    e.reply(w.isEmpty()?"Keine Warnungen.":String.join("\n",w)).setEphemeral(true).queue();
                }
                case "clear" -> {
                    if(!mod(e)) return;
                    int n=Math.min(e.getOption("amount").getAsInt(),100);
                    e.getChannel().getHistory().retrievePast(n).queue(ms ->
                        e.getChannel().purgeMessages(ms).queue(v ->
                            e.reply("🧹 "+ms.size()+" Nachrichten gelöscht.").setEphemeral(true).queue()));
                }
                case "kick" -> {
                    if(!mod(e)) return;
                    var m=e.getOption("user").getAsMember();
                    if(m==null){e.reply("❌ Nicht auf dem Server.").setEphemeral(true).queue();return;}
                    e.getGuild().kick(m).queue(v->e.reply("👢 Gekickt: "+m.getAsMention()).queue(),
                            x->e.reply("❌ Kick fehlgeschlagen.").setEphemeral(true).queue());
                }
                case "ban" -> {
                    if(!mod(e)) return;
                    User u=e.getOption("user").getAsUser();
                    e.getGuild().ban(u,0,"Moderation durch "+e.getUser().getAsTag()).queue(
                            v->e.reply("🔨 Gebannt: "+u.getAsMention()).queue(),
                            x->e.reply("❌ Ban fehlgeschlagen.").setEphemeral(true).queue());
                }
                case "timeout" -> {
                    if(!mod(e)) return;
                    var m=e.getOption("user").getAsMember();
                    int min=Math.max(1,Math.min(e.getOption("minutes").getAsInt(),40320));
                    if(m==null){e.reply("❌ Nicht auf dem Server.").setEphemeral(true).queue();return;}
                    m.timeoutFor(Duration.ofMinutes(min)).reason("Moderation").queue(
                            v->e.reply("🔇 Timeout für "+min+" Minuten: "+m.getAsMention()).queue(),
                            x->e.reply("❌ Timeout fehlgeschlagen.").setEphemeral(true).queue());
                }
            }
        } catch(Exception ex) { e.reply("❌ Fehler: "+ex.getMessage()).setEphemeral(true).queue(); }
    }
}
