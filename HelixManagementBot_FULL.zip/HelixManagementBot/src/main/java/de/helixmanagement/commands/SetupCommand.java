package de.helixmanagement.commands;

import de.helixmanagement.db.Database;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class SetupCommand extends ListenerAdapter {
    public void onSlashCommandInteraction(SlashCommandInteractionEvent e) {
        if(!e.getName().equals("setup")) return;
        if(!e.getMember().hasPermission(Permission.ADMINISTRATOR)) {
            e.reply("❌ Administrator erforderlich.").setEphemeral(true).queue();return;
        }
        var g=e.getGuild();
        e.deferReply(true).queue();
        g.createRole().setName("Verified").queue(role -> {
            try { Database.set(g.getId(),"verify_role",role.getId()); } catch(Exception x){x.printStackTrace();}
        });
        g.createCategory("MANAGEMENT").queue(cat -> {
            cat.createTextChannel("tickets").queue();
            cat.createTextChannel("bewerbungen").queue();
            cat.createTextChannel("verification").queue();
            cat.createTextChannel("logs").queue(ch -> {
                try {Database.set(g.getId(),"log_channel",ch.getId());}catch(Exception x){x.printStackTrace();}
            });
            cat.createVoiceChannel("➕・Create Room").queue(ch -> {
                try {Database.set(g.getId(),"tempvoice_channel",ch.getId());}catch(Exception x){x.printStackTrace();}
            });
        });
        e.getHook().sendMessage("✅ Setup gestartet. Erstellt Management-Kategorie, Kanäle, Verified-Rolle und TempVoice-Trigger.").queue();
    }
}
