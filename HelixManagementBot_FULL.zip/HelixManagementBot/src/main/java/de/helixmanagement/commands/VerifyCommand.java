package de.helixmanagement.commands;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.components.buttons.Button;

public class VerifyCommand extends ListenerAdapter {
    public void onSlashCommandInteraction(SlashCommandInteractionEvent e) {
        if(!e.getName().equals("verify"))return;
        e.replyEmbeds(new EmbedBuilder().setTitle("🔐 Verifizierung")
                .setDescription("Klicke auf den Button.").build())
                .addActionRow(Button.success("verify:me","✅ Verifizieren")).queue();
    }
}
