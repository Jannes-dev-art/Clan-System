package de.helixmanagement.commands;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class BasicCommands extends ListenerAdapter {
    public void onSlashCommandInteraction(SlashCommandInteractionEvent e) {
        switch(e.getName()) {
            case "ping" -> e.reply("🏓 Pong! `" + e.getJDA().getGatewayPing() + "ms`").queue();
            case "userinfo" -> {
                var u=e.getOption("user")==null?e.getUser():e.getOption("user").getAsUser();
                e.replyEmbeds(new EmbedBuilder().setTitle("👤 Userinfo")
                        .addField("Name",u.getAsTag(),true)
                        .addField("ID",u.getId(),true)
                        .addField("Erstellt",u.getTimeCreated().toString(),false)
                        .setThumbnail(u.getEffectiveAvatarUrl()).build()).queue();
            }
            case "serverinfo" -> {
                var g=e.getGuild();
                e.replyEmbeds(new EmbedBuilder().setTitle("📊 Serverinfo")
                        .addField("Name",g.getName(),true)
                        .addField("Mitglieder",String.valueOf(g.getMemberCount()),true)
                        .addField("ID",g.getId(),true).build()).queue();
            }
        }
    }
}
