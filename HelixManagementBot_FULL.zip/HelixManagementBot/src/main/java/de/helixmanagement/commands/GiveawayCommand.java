package de.helixmanagement.commands;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.components.buttons.Button;
import java.util.*;
import java.util.concurrent.*;

public class GiveawayCommand extends ListenerAdapter {
    public static final Map<Long, Set<Long>> entries=new ConcurrentHashMap<>();
    public static final Map<Long,String> prizes=new ConcurrentHashMap<>();

    public void onSlashCommandInteraction(SlashCommandInteractionEvent e) {
        if(!e.getName().equals("giveaway"))return;
        String prize=e.getOption("prize").getAsString();
        int seconds=Math.max(5,Math.min(e.getOption("seconds").getAsInt(),604800));
        e.replyEmbeds(new EmbedBuilder().setTitle("🎉 Giveaway")
                .setDescription("**Preis:** "+prize+"\n**Dauer:** "+seconds+" Sekunden\n\nKlicke auf den Button!").build())
                .addActionRow(Button.success("giveaway:join","🎉 Teilnehmen")).queue();
        e.getHook().retrieveOriginal().queue(m->{
            entries.put(m.getIdLong(),ConcurrentHashMap.newKeySet());
            prizes.put(m.getIdLong(),prize);
            CompletableFuture.delayedExecutor(seconds,TimeUnit.SECONDS).execute(()->{
                Set<Long> set=entries.remove(m.getIdLong());
                String p=prizes.remove(m.getIdLong());
                if(set==null||set.isEmpty()){
                    m.editMessageEmbeds(new EmbedBuilder().setTitle("🎉 Giveaway beendet")
                            .setDescription("Keine Teilnehmer.").build()).queue(); return;
                }
                List<Long> list=new ArrayList<>(set);
                long winner=list.get(ThreadLocalRandom.current().nextInt(list.size()));
                m.editMessageEmbeds(new EmbedBuilder().setTitle("🎉 Giveaway beendet")
                        .setDescription("**"+p+"**\nGewinner: <@"+winner+">").build()).queue();
            });
        });
    }
}
