package de.helixmanagement.commands;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class AnnouncementCommand extends ListenerAdapter {
    public void onSlashCommandInteraction(SlashCommandInteractionEvent e) {
        if(!e.getName().equals("announce"))return;
        if(!e.getMember().hasPermission(net.dv8tion.jda.api.Permission.MANAGE_CHANNEL)) {
            e.reply("❌ Keine Berechtigung.").setEphemeral(true).queue();return;
        }
        String text=e.getOption("text").getAsString();
        e.getChannel().sendMessageEmbeds(new EmbedBuilder().setTitle("📢 Ankündigung")
                .setDescription(text).setFooter("Management").build()).queue();
        e.reply("✅ Gesendet.").setEphemeral(true).queue();
    }
}
